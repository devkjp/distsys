/*===================================================================
 * DHBW Ravensburg - Campus Friedrichshafen
 *
 * Vorlesung Verteilte Systeme
 *
 * Author:  Ralf Reutemann
 *
 *===================================================================*/

#ifndef _SAFE_PRINT_H
#define _SAFE_PRINT_H

extern int safe_printf(const char *format, ...);

#endif

