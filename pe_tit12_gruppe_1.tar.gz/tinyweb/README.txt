Abgabe des Programmentwurfs Verteilte Systeme
============================================

Kurs: 		TIT12
Gruppe: 	1
Mitglieder: 	Christian Reutebuch
		Leander Schulz
		Jonas Polkehn

Kommentare zur Abgabe:
- Auf Ihre Anfrage hin haben wir die longtext aus dem Verzeichnis web/ gelöscht. Bitte fügen Sie sie vor dem Testen erneut hinzu.

